#-*-coding:utf-8-*-
#위 구문은 한글처리를 위해 필수임.
#
import urllib.request
import json
import datetime

openweather_api_url = "https://api.openweathermap.org/data/2.5/"
service_key = "c7446d3b017961049805343e08347b43"

# 각 딕셔너리 데이터를 하나로 합치는 함수 작성.
# 모든 함수를 그냥 클래스로 만들자 ^^;

def getNowCity(city) :
	global openweather_api_url, service_key
	ow_api_url = openweather_api_url + "weather"
	
	# 요청할 관련 정보 설정
	payload = "?q=" + city + "&" +\
		"appid=" + service_key 

	# API 요청
	url_total = ow_api_url + payload
	print(url_total)
	req = urllib.request.urlopen(url_total)
	res = req.readline()

	# 받은 값 JSON 형태로 정제하여 반환
	items = json.loads(res)
	print("============================")
	print(items)

	print("============================")
	
	print("weat=> %r" % items['weather'][0]['main'])
	print("temp=> %r" % str(int(items['main']['temp'])-273.15))
	
	print("============================")
	

	# 미세먼지 값 불러오기 (대기상태)
	ow_api_url = openweather_api_url + "air_pollution"
	payload = "?lat=" + str(items['coord']['lat']) + "&" +\
			   "lon=" + str(items['coord']['lon']) + "&" +\
			   "appid=" + service_key

	# API 요청
	url_total = ow_api_url + payload
	print(url_total)
	req = urllib.request.urlopen(url_total)
	res = req.readline()

	items = json.loads(res)
	print(items)


'''
	weather_data = "{"
	for item in items['response']['body']['items']['item']:
		print(item['category'])
		print(item['obsrValue'])
		weather_data = weather_data + '"' + item['category'] + '":"' + item['obsrValue'] + '",'
	weather_data = weather_data[:-1] #가장 끝 문자 1개 제거
	weather_data = weather_data + "}"
		
	return weather_data
'''
		
	
if __name__ == "__main__":
	print("main")
	getNowCity("Seoul")

