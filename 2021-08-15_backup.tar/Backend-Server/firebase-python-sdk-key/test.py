import os

os.system("python3 ./realtimedb_sample.py &")
os.system("python3 ./firestore_sample.py &")

