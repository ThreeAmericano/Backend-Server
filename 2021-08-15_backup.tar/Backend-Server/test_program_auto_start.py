import os

while True :
	os.system('python3 ./backend_process.py')
	print('===restart program===')

